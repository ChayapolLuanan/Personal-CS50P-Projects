def main():
    ...





main()
