guest_input = input("")
print(guest_input.lower())
